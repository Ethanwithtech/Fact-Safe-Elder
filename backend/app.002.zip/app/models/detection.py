"""
检测服务数据模型定义
"""

from enum import Enum
from typing import List, Optional, Any, Dict
from datetime import datetime
from pydantic import BaseModel, Field, validator
import time


class RiskLevel(str, Enum):
    """风险等级枚举"""
    SAFE = "safe"
    WARNING = "warning"  
    DANGER = "danger"


class DetectionResult(BaseModel):
    """检测结果模型"""
    level: RiskLevel = Field(..., description="风险等级")
    score: float = Field(..., ge=0, le=1, description="风险评分(0-1)")
    confidence: float = Field(..., ge=0, le=1, description="置信度(0-1)")
    message: str = Field(..., description="检测消息")
    reasons: List[str] = Field(default=[], description="风险原因列表")
    suggestions: List[str] = Field(default=[], description="安全建议列表")
    categories: List[str] = Field(default=[], description="风险分类")
    keywords: List[str] = Field(default=[], description="关键词")
    detection_id: str = Field(..., description="检测唯一ID")
    timestamp: datetime = Field(default_factory=datetime.now, description="检测时间")
    
    # AI特有字段
    ai_models_used: Optional[List[str]] = Field(default=[], description="使用的AI模型")
    explanation_report: Optional[Dict[str, Any]] = Field(default=None, description="详细解释报告")
    feature_importance: Optional[Dict[str, float]] = Field(default=None, description="特征重要性")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
        json_schema_extra = {
            "example": {
                "level": "warning",
                "score": 0.7,
                "confidence": 0.85,
                "message": "检测到可疑的投资理财内容",
                "reasons": ["发现高收益投资承诺", "包含联系方式"],
                "suggestions": ["谨慎对待投资信息", "如有疑问请咨询家人"],
                "categories": ["financial_fraud"],
                "keywords": ["保证收益", "月入万元"],
                "detection_id": "det_1640995200_abc123",
                "timestamp": "2025-01-27T10:30:00",
                "ai_models_used": ["chatglm", "bert"],
                "explanation_report": {
                    "summary": "基于2个AI模型的综合分析",
                    "model_consensus": "85%的模型一致性"
                }
            }
        }


class DetectionRequest(BaseModel):
    """检测请求模型"""
    text: str = Field(..., min_length=1, max_length=5000, description="待检测的文本内容")
    user_id: Optional[str] = Field(default=None, description="用户ID")
    platform: Optional[str] = Field(default="unknown", description="来源平台")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="额外元数据")
    
    @validator('text')
    def validate_text(cls, v):
        if not v or not v.strip():
            raise ValueError('文本内容不能为空')
        return v.strip()
    
    class Config:
        json_schema_extra = {
            "example": {
                "text": "月入三万的理财秘诀，保证收益！",
                "user_id": "user_123",
                "platform": "douyin",
                "metadata": {
                    "video_id": "video_456",
                    "duration": 30
                }
            }
        }


class DetectionResponse(BaseModel):
    """检测响应模型"""
    success: bool = Field(..., description="请求是否成功")
    message: str = Field(..., description="响应消息")
    code: int = Field(..., description="状态码")
    data: DetectionResult = Field(..., description="检测结果")
    processing_time: Optional[float] = Field(default=None, description="处理时间(秒)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "message": "检测完成",
                "code": 200,
                "data": {
                    "level": "warning",
                    "score": 0.7,
                    "confidence": 0.85,
                    "message": "检测到可疑的投资理财内容",
                    "reasons": ["发现高收益投资承诺"],
                    "suggestions": ["谨慎对待投资信息"],
                    "detection_id": "det_1640995200_abc123"
                },
                "processing_time": 0.236
            }
        }


class BatchDetectionRequest(BaseModel):
    """批量检测请求模型"""
    texts: List[str] = Field(..., min_items=1, max_items=10, description="待检测的文本列表")
    user_id: Optional[str] = Field(default=None, description="用户ID")
    platform: Optional[str] = Field(default="unknown", description="来源平台")
    
    @validator('texts')
    def validate_texts(cls, v):
        if not v:
            raise ValueError('文本列表不能为空')
        
        for i, text in enumerate(v):
            if not text or not text.strip():
                raise ValueError(f'第{i+1}个文本不能为空')
            if len(text) > 5000:
                raise ValueError(f'第{i+1}个文本长度超过5000字符')
        
        return [text.strip() for text in v]
    
    class Config:
        json_schema_extra = {
            "example": {
                "texts": [
                    "月入三万的理财秘诀",
                    "祖传秘方包治百病",
                    "正常的新闻内容"
                ],
                "user_id": "user_123",
                "platform": "douyin"
            }
        }


class DetectionStats(BaseModel):
    """检测统计信息模型"""
    total_detections: int = Field(default=0, description="总检测次数")
    safe_count: int = Field(default=0, description="安全内容数量")
    warning_count: int = Field(default=0, description="警告内容数量") 
    danger_count: int = Field(default=0, description="危险内容数量")
    avg_processing_time: float = Field(default=0.0, description="平均处理时间")
    last_detection_time: Optional[datetime] = Field(default=None, description="最后检测时间")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
        json_schema_extra = {
            "example": {
                "total_detections": 1250,
                "safe_count": 800,
                "warning_count": 300,
                "danger_count": 150,
                "avg_processing_time": 0.85,
                "last_detection_time": "2025-01-27T10:30:00"
            }
        }


class DetectionHistory(BaseModel):
    """检测历史记录模型"""
    id: str = Field(..., description="记录ID")
    user_id: Optional[str] = Field(default=None, description="用户ID")
    content: str = Field(..., description="检测内容")
    result: DetectionResult = Field(..., description="检测结果")
    platform: str = Field(default="unknown", description="来源平台")
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class FeedbackRequest(BaseModel):
    """反馈请求模型"""
    detection_id: str = Field(..., description="检测ID")
    feedback: str = Field(..., min_length=1, max_length=1000, description="反馈内容")
    rating: int = Field(..., ge=1, le=5, description="评分(1-5)")
    user_id: Optional[str] = Field(default=None, description="用户ID")
    
    @validator('feedback')
    def validate_feedback(cls, v):
        if not v or not v.strip():
            raise ValueError('反馈内容不能为空')
        return v.strip()
    
    class Config:
        json_schema_extra = {
            "example": {
                "detection_id": "det_1640995200_abc123",
                "feedback": "检测结果准确",
                "rating": 5,
                "user_id": "user_123"
            }
        }


class UserSettings(BaseModel):
    """用户设置模型"""
    user_id: str = Field(..., description="用户ID")
    font_size: str = Field(default="large", description="字体大小")
    high_contrast: bool = Field(default=True, description="高对比度模式")
    sensitivity: str = Field(default="medium", description="检测敏感度")
    enable_sound: bool = Field(default=True, description="启用声音提示")
    family_contact: Optional[str] = Field(default=None, description="家人联系方式")
    notification_threshold: str = Field(default="warning", description="通知阈值")
    
    @validator('font_size')
    def validate_font_size(cls, v):
        allowed = ['normal', 'large', 'extra-large']
        if v not in allowed:
            raise ValueError(f'字体大小必须是: {allowed}')
        return v
    
    @validator('sensitivity')
    def validate_sensitivity(cls, v):
        allowed = ['low', 'medium', 'high']
        if v not in allowed:
            raise ValueError(f'敏感度必须是: {allowed}')
        return v
    
    @validator('notification_threshold')
    def validate_notification_threshold(cls, v):
        allowed = ['warning', 'danger', 'never']
        if v not in allowed:
            raise ValueError(f'通知阈值必须是: {allowed}')
        return v
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user_123",
                "font_size": "large",
                "high_contrast": True,
                "sensitivity": "medium",
                "enable_sound": True,
                "family_contact": "138****1234",
                "notification_threshold": "warning"
            }
        }


# 用于API响应的通用模型
class ApiResponse(BaseModel):
    """通用API响应模型"""
    success: bool = Field(..., description="请求是否成功")
    message: str = Field(..., description="响应消息")
    code: int = Field(..., description="状态码")
    data: Optional[Any] = Field(default=None, description="响应数据")
    timestamp: datetime = Field(default_factory=datetime.now, description="响应时间")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


# 流式响应相关模型
class StreamingDetectionUpdate(BaseModel):
    """流式检测更新模型"""
    detection_id: str = Field(..., description="检测ID")
    status: str = Field(..., description="当前状态")
    progress: float = Field(..., ge=0, le=1, description="进度(0-1)")
    partial_result: Optional[Dict[str, Any]] = Field(default=None, description="部分结果")
    timestamp: datetime = Field(default_factory=datetime.now, description="更新时间")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
