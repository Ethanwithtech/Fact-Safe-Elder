"""
数据模型包
"""

from .detection import (
    DetectionRequest,
    DetectionResponse,
    BatchDetectionRequest,
    DetectionResult,
    RiskLevel,
    DetectionStats
)

__all__ = [
    "DetectionRequest",
    "DetectionResponse", 
    "BatchDetectionRequest",
    "DetectionResult",
    "RiskLevel",
    "DetectionStats"
]
