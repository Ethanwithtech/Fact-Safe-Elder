import React, { useState } from 'react';
import { Button, Upload, message, Card, Typography, Space } from 'antd';
import { UploadOutlined, LoadingOutlined } from '@ant-design/icons';
import type { UploadFile } from 'antd';
import axios from 'axios';
import { DetectionResult } from '../../types/detection';
import './VideoUpload.css';

const { Text, Title } = Typography;

interface VideoUploadProps {
  onDetectionResult: (result: DetectionResult) => void;
}

const VideoUpload: React.FC<VideoUploadProps> = ({ onDetectionResult }) => {
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);

  const handleUpload = async () => {
    if (fileList.length === 0) {
      message.error('请先选择视频文件');
      return;
    }

    const file = fileList[0].originFileObj;
    if (!file) {
      message.error('文件无效');
      return;
    }

    setUploading(true);
    setDetectionResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:8000/detect/video', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 300000, // 5分钟超时
      });

      const result: DetectionResult = response.data.data;
      setDetectionResult(result);
      onDetectionResult(result);
      message.success('视频检测完成');
    } catch (error: any) {
      console.error('视频检测失败:', error);
      message.error(`检测失败: ${error.response?.data?.detail || error.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = () => {
    setFileList([]);
    setDetectionResult(null);
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'danger':
        return 'var(--color-danger)';
      case 'warning':
        return 'var(--color-warning)';
      default:
        return 'var(--color-success)';
    }
  };

  const getRiskLevelText = (level: string) => {
    switch (level) {
      case 'danger':
        return '高风险';
      case 'warning':
        return '有风险';
      default:
        return '安全';
    }
  };

  return (
    <div className="video-upload">
      <div className="upload-area">
        <Upload
          accept="video/*"
          fileList={fileList}
          beforeUpload={() => false}
          onChange={(info) => setFileList(info.fileList)}
          onRemove={handleRemove}
          maxCount={1}
        >
          <Button 
            icon={<UploadOutlined />} 
            size="large"
            disabled={uploading}
            className="upload-btn"
          >
            选择视频文件
          </Button>
        </Upload>
        
        {fileList.length > 0 && (
          <Button
            type="primary"
            onClick={handleUpload}
            loading={uploading}
            size="large"
            className="detect-btn"
          >
            {uploading ? '检测中...' : '开始检测'}
          </Button>
        )}
      </div>

      {detectionResult && (
        <Card className="result-card" bordered>
          <div className="result-header">
            <Title level={4} style={{ 
              color: getRiskLevelColor(detectionResult.level),
              margin: 0 
            }}>
              {getRiskLevelText(detectionResult.level)}
            </Title>
            <Text type="secondary">
              风险分数: {(detectionResult.score || 0).toFixed(2)} | 
              置信度: {(detectionResult.confidence || 0).toFixed(2)}
            </Text>
          </div>

          {detectionResult.message && (
            <div className="result-message">
              <Text>{detectionResult.message}</Text>
            </div>
          )}

          {detectionResult.reasons && detectionResult.reasons.length > 0 && (
            <div className="result-reasons">
              <Text strong>风险原因：</Text>
              <ul>
                {detectionResult.reasons.map((reason, idx) => (
                  <li key={idx}>{reason}</li>
                ))}
              </ul>
            </div>
          )}

          {detectionResult.suggestions && detectionResult.suggestions.length > 0 && (
            <div className="result-suggestions">
              <Text strong>建议：</Text>
              <ul>
                {detectionResult.suggestions.map((suggestion, idx) => (
                  <li key={idx}>{suggestion}</li>
                ))}
              </ul>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

export default VideoUpload;

