import React, { useState } from 'react';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import './App.css';
import MobileSimulator from './components/MobileSimulator/MobileSimulator';
import VideoUpload from './components/VideoUpload/VideoUpload';
import DetectionFloater from './components/DetectionFloater/DetectionFloater';
import { DetectionResult } from './types/detection';

function App() {
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);

  const handleDetectionResult = (result: DetectionResult) => {
    setDetectionResult(result);
    
    // 如果检测到高风险，播放警告音
    if (result.level === 'danger') {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.5);
    }
  };

  return (
    <ConfigProvider locale={zhCN}>
      <div className="app">
        <header className="app-header">
          <div className="header-content">
            <h1>🛡️ 老人短视频虚假信息检测系统</h1>
          </div>
        </header>

        <main className="app-main">
          <div className="main-container">
            {/* 手机模拟检测 */}
            <section className="section-mobile">
              <h2 className="section-title">📱 手机模拟检测</h2>
              <div className="section-content">
                <MobileSimulator onDetectionResult={handleDetectionResult} />
              </div>
            </section>

            {/* 视频上传检测 */}
            <section className="section-upload">
              <h2 className="section-title">📹 上传视频检测</h2>
              <div className="section-content">
                <VideoUpload onDetectionResult={handleDetectionResult} />
              </div>
            </section>
          </div>
          
          {/* 全局检测浮窗 */}
          {detectionResult && (
            <DetectionFloater 
              result={detectionResult}
              onClose={() => setDetectionResult(null)}
            />
          )}
        </main>
      </div>
    </ConfigProvider>
  );
}

export default App;
